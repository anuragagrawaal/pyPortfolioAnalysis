
VERSION = (0, 0, 900)

__version__ = '.'.join(map(str, VERSION))
